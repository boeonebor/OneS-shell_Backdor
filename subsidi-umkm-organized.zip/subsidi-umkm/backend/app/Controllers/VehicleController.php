<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vehicle;
use Illuminate\Support\Facades\Storage;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class VehicleController extends Controller
{
    /**
     * Get all vehicles for authenticated user
     */
    public function index(Request $request)
    {
        $user = $request->user();
        
        $vehicles = Vehicle::where('user_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->get();
        
        return response()->json([
            'success' => true,
            'data' => $vehicles
        ]);
    }

    /**
     * Add new vehicle
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'plat_nomor' => 'required|string|unique:vehicles,plat_nomor',
            'roda' => 'required|in:2,4,6',
            'foto_kendaraan' => 'required|image|max:5120', // 5MB max
            'produk_bbm' => 'nullable|string'
        ]);

        $user = $request->user();

        // Upload foto
        $fotoPath = null;
        if ($request->hasFile('foto_kendaraan')) {
            $fotoPath = $request->file('foto_kendaraan')->store('vehicles', 'public');
        }

        // Create vehicle
        $vehicle = Vehicle::create([
            'user_id' => $user->id,
            'plat_nomor' => strtoupper($validated['plat_nomor']),
            'roda' => $validated['roda'],
            'foto_kendaraan' => $fotoPath,
            'produk_bbm' => $validated['produk_bbm'] ?? 'Pertalite',
            'status' => 'pending', // pending, approved, rejected
            'verified_at' => null
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Kendaraan berhasil ditambahkan',
            'data' => $vehicle
        ], 201);
    }

    /**
     * Get vehicle detail
     */
    public function show($id)
    {
        $vehicle = Vehicle::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        return response()->json([
            'success' => true,
            'data' => $vehicle
        ]);
    }

    /**
     * Update vehicle
     */
    public function update(Request $request, $id)
    {
        $vehicle = Vehicle::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        $validated = $request->validate([
            'plat_nomor' => 'string|unique:vehicles,plat_nomor,' . $id,
            'roda' => 'in:2,4,6',
            'foto_kendaraan' => 'nullable|image|max:5120',
            'produk_bbm' => 'nullable|string'
        ]);

        // Upload new foto if exists
        if ($request->hasFile('foto_kendaraan')) {
            // Delete old foto
            if ($vehicle->foto_kendaraan) {
                Storage::disk('public')->delete($vehicle->foto_kendaraan);
            }
            $validated['foto_kendaraan'] = $request->file('foto_kendaraan')->store('vehicles', 'public');
        }

        $vehicle->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Kendaraan berhasil diupdate',
            'data' => $vehicle
        ]);
    }

    /**
     * Delete vehicle
     */
    public function destroy($id)
    {
        $vehicle = Vehicle::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        // Delete foto
        if ($vehicle->foto_kendaraan) {
            Storage::disk('public')->delete($vehicle->foto_kendaraan);
        }

        // Delete QR if exists
        if ($vehicle->qr_code_path) {
            Storage::disk('public')->delete($vehicle->qr_code_path);
        }

        $vehicle->delete();

        return response()->json([
            'success' => true,
            'message' => 'Kendaraan berhasil dihapus'
        ]);
    }

    /**
     * Generate QR Code for approved vehicle
     */
    public function generateQR($id)
    {
        $vehicle = Vehicle::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        if ($vehicle->status !== 'approved') {
            return response()->json([
                'success' => false,
                'message' => 'Kendaraan belum diverifikasi'
            ], 400);
        }

        // QR Code data structure (sesuai format Pertamina)
        $qrData = json_encode([
            'vehicle_id' => $vehicle->id,
            'plat_nomor' => $vehicle->plat_nomor,
            'user_id' => $vehicle->user_id,
            'produk_bbm' => $vehicle->produk_bbm,
            'roda' => $vehicle->roda,
            'expired_at' => now()->addMonths(3)->format('Y-m-d'), // 3 bulan validity
            'hash' => hash('sha256', $vehicle->plat_nomor . $vehicle->user_id . config('app.key'))
        ]);

        // Generate QR Code
        $qrCode = QrCode::format('png')
            ->size(300)
            ->errorCorrection('H')
            ->generate($qrData);

        // Save QR Code
        $filename = 'qrcodes/' . $vehicle->plat_nomor . '_' . time() . '.png';
        Storage::disk('public')->put($filename, $qrCode);

        // Update vehicle
        $vehicle->update([
            'qr_code_path' => $filename,
            'qr_code_data' => $qrData,
            'qr_generated_at' => now()
        ]);

        return response()->json([
            'success' => true,
            'message' => 'QR Code berhasil dibuat',
            'data' => [
                'qr_code_url' => Storage::url($filename),
                'qr_code_data' => $qrData
            ]
        ]);
    }

    /**
     * Get QR Code
     */
    public function getQR($id)
    {
        $vehicle = Vehicle::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        if (!$vehicle->qr_code_path) {
            return response()->json([
                'success' => false,
                'message' => 'QR Code belum dibuat'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'qr_code_url' => Storage::url($vehicle->qr_code_path),
                'qr_code_data' => $vehicle->qr_code_data,
                'generated_at' => $vehicle->qr_generated_at
            ]
        ]);
    }

    /**
     * Filter vehicles by status
     */
    public function filterByStatus(Request $request)
    {
        $status = $request->query('status', 'all'); // all, pending, approved, rejected
        $produk = $request->query('produk_bbm', 'all');
        $search = $request->query('search', '');

        $query = Vehicle::where('user_id', auth()->id());

        if ($status !== 'all') {
            $query->where('status', $status);
        }

        if ($produk !== 'all') {
            $query->where('produk_bbm', $produk);
        }

        if ($search) {
            $query->where('plat_nomor', 'like', '%' . $search . '%');
        }

        $vehicles = $query->orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => $vehicles
        ]);
    }
}

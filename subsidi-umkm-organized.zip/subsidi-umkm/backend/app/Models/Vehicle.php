<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vehicle extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'plat_nomor',
        'roda',
        'foto_kendaraan',
        'produk_bbm',
        'status',
        'verified_at',
        'verified_by',
        'rejection_reason',
        'qr_code_path',
        'qr_code_data',
        'qr_generated_at'
    ];

    protected $casts = [
        'verified_at' => 'datetime',
        'qr_generated_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    protected $appends = ['status_label', 'foto_url', 'qr_url'];

    /**
     * Get status label
     */
    public function getStatusLabelAttribute()
    {
        $labels = [
            'pending' => 'Menunggu Verifikasi',
            'approved' => 'Verifikasi Berhasil',
            'rejected' => 'Verifikasi Ditolak'
        ];

        return $labels[$this->status] ?? 'Unknown';
    }

    /**
     * Get foto URL
     */
    public function getFotoUrlAttribute()
    {
        if (!$this->foto_kendaraan) {
            return null;
        }

        return asset('storage/' . $this->foto_kendaraan);
    }

    /**
     * Get QR URL
     */
    public function getQrUrlAttribute()
    {
        if (!$this->qr_code_path) {
            return null;
        }

        return asset('storage/' . $this->qr_code_path);
    }

    /**
     * Relationship with User
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relationship with Verifier (Admin)
     */
    public function verifier()
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    /**
     * Scope for approved vehicles
     */
    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    /**
     * Scope for pending vehicles
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope for rejected vehicles
     */
    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }
}

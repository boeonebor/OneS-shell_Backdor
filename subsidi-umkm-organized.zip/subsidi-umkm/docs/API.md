# Subsidi UMKM - Backend API

Backend API untuk sistem subsidi BBM UMKM (versi wilayah).

## 🚀 Tech Stack

- **Framework:** Laravel 11
- **Database:** MySQL 8.0+
- **Authentication:** JWT (tymon/jwt-auth)
- **QR Code:** simplesoftwareio/simple-qrcode
- **PHP:** 8.2+

## 📋 Requirements

- PHP >= 8.2
- Composer
- MySQL >= 8.0
- Extension: OpenSSL, PDO, Mbstring, Tokenizer, XML, Ctype, JSON, BCMath, Fileinfo, GD

## 🔧 Installation

### 1. Clone Repository

```bash
git clone <repository-url>
cd subsidi-umkm-backend
```

### 2. Install Dependencies

```bash
composer install
```

### 3. Environment Setup

```bash
cp .env.example .env
php artisan key:generate
php artisan jwt:secret
```

Edit `.env` file:
```env
DB_DATABASE=subsidi_umkm
DB_USERNAME=root
DB_PASSWORD=your_password

PERTAMINA_API_URL=https://api.mypertamina.id/v1
PERTAMINA_API_KEY=your_api_key
PERTAMINA_API_SECRET=your_api_secret
```

### 4. Database Setup

```bash
# Create database
mysql -u root -p -e "CREATE DATABASE subsidi_umkm"

# Run migrations
php artisan migrate

# Seed data (optional)
php artisan db:seed
```

### 5. Storage Link

```bash
php artisan storage:link
```

### 6. Run Server

```bash
php artisan serve
# API akan berjalan di http://localhost:8000
```

## 📡 API Endpoints

### Authentication

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "081234567890",
  "password": "password123",
  "password_confirmation": "password123",
  "nik": "1234567890123456",
  "alamat": "Jl. Example No. 123"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

Response:
```json
{
  "success": true,
  "message": "Login berhasil",
  "data": {
    "user": {...},
    "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "token_type": "bearer"
  }
}
```

#### Get Profile
```http
GET /api/auth/me
Authorization: Bearer {token}
```

#### Logout
```http
POST /api/auth/logout
Authorization: Bearer {token}
```

### Vehicles

#### Get All Vehicles
```http
GET /api/vehicles
Authorization: Bearer {token}
```

#### Add Vehicle
```http
POST /api/vehicles
Authorization: Bearer {token}
Content-Type: multipart/form-data

plat_nomor: "BK 1234 AB"
roda: "4"
foto_kendaraan: <file>
produk_bbm: "Pertalite"
```

#### Get Vehicle Detail
```http
GET /api/vehicles/{id}
Authorization: Bearer {token}
```

#### Update Vehicle
```http
PUT /api/vehicles/{id}
Authorization: Bearer {token}
Content-Type: multipart/form-data

plat_nomor: "BK 5678 CD"
roda: "6"
```

#### Delete Vehicle
```http
DELETE /api/vehicles/{id}
Authorization: Bearer {token}
```

#### Generate QR Code
```http
POST /api/vehicles/{id}/generate-qr
Authorization: Bearer {token}
```

Response:
```json
{
  "success": true,
  "message": "QR Code berhasil dibuat",
  "data": {
    "qr_code_url": "http://localhost:8000/storage/qrcodes/BK1234AB_1234567890.png",
    "qr_code_data": "{...}"
  }
}
```

#### Get QR Code
```http
GET /api/vehicles/{id}/qr
Authorization: Bearer {token}
```

#### Filter Vehicles
```http
GET /api/vehicles/filter?status=approved&produk_bbm=Pertalite&search=BK
Authorization: Bearer {token}
```

### Admin (Role: admin)

#### Get All Vehicles (Admin)
```http
GET /api/admin/vehicles
Authorization: Bearer {admin_token}
```

#### Approve Vehicle
```http
POST /api/admin/vehicles/{id}/approve
Authorization: Bearer {admin_token}
```

#### Reject Vehicle
```http
POST /api/admin/vehicles/{id}/reject
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "rejection_reason": "Foto tidak jelas"
}
```

## 🔐 Authentication

Semua request ke protected endpoints harus menyertakan JWT token di header:

```http
Authorization: Bearer {your_jwt_token}
```

Token akan expired dalam 60 menit (default), gunakan endpoint `/api/auth/refresh` untuk mendapatkan token baru.

## 📁 File Structure

```
subsidi-umkm-backend/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php
│   │   │   ├── VehicleController.php
│   │   │   └── AdminController.php
│   │   └── Middleware/
│   │       └── IsAdmin.php
│   └── Models/
│       ├── User.php
│       └── Vehicle.php
├── database/
│   ├── migrations/
│   │   ├── create_users_table.php
│   │   └── create_vehicles_table.php
│   └── seeders/
├── routes/
│   └── api.php
├── storage/
│   └── app/
│       └── public/
│           ├── vehicles/
│           └── qrcodes/
└── .env.example
```

## 🎯 QR Code Format

QR Code berisi data JSON dengan struktur:

```json
{
  "vehicle_id": 123,
  "plat_nomor": "BK 1234 AB",
  "user_id": 456,
  "produk_bbm": "Pertalite",
  "roda": "4",
  "expired_at": "2024-05-18",
  "hash": "sha256_hash_for_validation"
}
```

## 🔄 Status Kendaraan

- `pending`: Menunggu verifikasi admin
- `approved`: Disetujui, bisa generate QR
- `rejected`: Ditolak oleh admin

## 📊 Database Schema

### users
- id (PK)
- name
- email (unique)
- phone (unique)
- password (hashed)
- nik (unique, nullable)
- alamat
- foto_profil
- role (user/admin)
- timestamps

### vehicles
- id (PK)
- user_id (FK → users)
- plat_nomor (unique)
- roda (2/4/6)
- foto_kendaraan
- produk_bbm
- status (pending/approved/rejected)
- verified_at
- verified_by (FK → users, nullable)
- rejection_reason
- qr_code_path
- qr_code_data
- qr_generated_at
- timestamps

## 🚧 Development

### Create Admin User

```bash
php artisan tinker
```

```php
User::create([
    'name' => 'Admin',
    'email' => 'admin@subsidi-umkm.com',
    'phone' => '081234567890',
    'password' => Hash::make('admin123'),
    'role' => 'admin'
]);
```

### Clear Cache

```bash
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
```

## 📝 Notes

- Semua foto disimpan di `storage/app/public/vehicles/`
- QR code disimpan di `storage/app/public/qrcodes/`
- Max file upload: 5MB
- QR code validity: 3 bulan
- JWT token TTL: 60 menit

## 🔗 Integrasi Pertamina API

Edit `config/services.php`:

```php
'pertamina' => [
    'api_url' => env('PERTAMINA_API_URL'),
    'api_key' => env('PERTAMINA_API_KEY'),
    'api_secret' => env('PERTAMINA_API_SECRET'),
],
```

## 📞 Support

Untuk pertanyaan atau issues, hubungi developer.

---

**Powered by Laravel 11**

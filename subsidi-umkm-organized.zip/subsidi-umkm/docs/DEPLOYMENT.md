# Subsidi UMKM - Frontend

Frontend aplikasi Subsidi BBM UMKM menggunakan React + Vite.

## 🚀 Tech Stack

- **Framework:** React 18
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **State Management:** Zustand
- **Routing:** React Router DOM v6
- **HTTP Client:** Axios
- **Icons:** React Icons
- **Notifications:** React Hot Toast
- **QR Code:** React QR Code

## 📋 Prerequisites

- Node.js >= 18.0.0
- npm atau yarn
- Backend API running di `http://localhost:8000`

## 🔧 Installation

### 1. Clone & Install

```bash
cd subsidi-umkm-frontend
npm install
```

### 2. Environment Setup

Create `.env` file:

```env
VITE_API_URL=http://localhost:8000/api
```

### 3. Run Development Server

```bash
npm run dev
# App akan berjalan di http://localhost:3000
```

### 4. Build Production

```bash
npm run build
# Output di folder dist/
```

## 📁 Project Structure

```
subsidi-umkm-frontend/
├── public/              # Static assets
├── src/
│   ├── components/      # Reusable components
│   │   ├── Layout.jsx
│   │   ├── VehicleCard.jsx
│   │   └── ProtectedRoute.jsx
│   ├── pages/          # Page components
│   │   ├── Login.jsx
│   │   ├── Register.jsx
│   │   ├── Dashboard.jsx
│   │   ├── AddVehicle.jsx
│   │   ├── VehicleDetail.jsx
│   │   └── Profile.jsx
│   ├── store/          # Zustand stores
│   │   └── authStore.js
│   ├── utils/          # Utilities
│   │   └── api.js
│   ├── App.jsx         # Main app component
│   ├── main.jsx        # Entry point
│   └── index.css       # Global styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

## 🎨 Features Implemented

### ✅ Authentication
- Login dengan email & password
- Register user baru
- JWT token management
- Auto logout on token expiry
- Protected routes

### ✅ Dashboard
- List semua kendaraan user
- Filter by status (pending/approved/rejected)
- Filter by produk BBM
- Search by plat nomor
- Statistics cards (total, approved, pending, rejected)

### ✅ Vehicle Management
- Tambah kendaraan baru (+ upload foto)
- Lihat detail kendaraan
- Generate QR code (untuk approved vehicles)
- Download QR code
- Edit kendaraan
- Hapus kendaraan

### ✅ Profile
- Lihat profil user
- Edit profil (nama, phone, NIK, alamat)
- Upload foto profil
- Change password

### ✅ UI/UX
- Responsive design (mobile, tablet, desktop)
- Glass morphism effect
- Smooth animations
- Toast notifications
- Loading states
- Error handling

## 🔐 Authentication Flow

```
1. User login → Get JWT token
2. Token stored in localStorage (via Zustand persist)
3. Every API request includes token in Authorization header
4. Token expiry (401) → Auto logout & redirect to login
```

## 📡 API Integration

All API calls via `src/utils/api.js`:

```javascript
import api from '@/utils/api'

// GET request
const { data } = await api.get('/vehicles')

// POST request
const { data } = await api.post('/vehicles', formData)

// PUT request
const { data } = await api.put(`/vehicles/${id}`, updateData)

// DELETE request
const { data } = await api.delete(`/vehicles/${id}`)
```

## 🎯 Key Components

### Layout Component
- Navbar dengan user info & logout
- Sidebar menu (desktop)
- Mobile responsive menu
- Footer

### VehicleCard Component
- Display vehicle info
- Status badge (pending/approved/rejected)
- Foto kendaraan
- Action buttons (detail, delete)

### ProtectedRoute Component
- Wrap protected pages
- Redirect to login if not authenticated

## 🌈 Tailwind CSS Classes

Custom classes tersedia di `src/index.css`:

```css
.card              /* White glassmorphism card */
.btn               /* Base button */
.btn-primary       /* Primary button (blue) */
.btn-danger        /* Danger button (red) */
.btn-outline       /* Outlined button */
.input             /* Form input */
.badge             /* Status badge */
.badge-pending     /* Yellow badge */
.badge-approved    /* Green badge */
.badge-rejected    /* Red badge */
```

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🚀 Deployment

### Deploy ke Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Production
vercel --prod
```

### Deploy ke Netlify

```bash
# Build
npm run build

# Upload dist/ folder ke Netlify
```

## 🔧 Environment Variables

```env
# API Base URL
VITE_API_URL=http://localhost:8000/api

# Optional: Enable debug
VITE_DEBUG=true
```

## 📝 Pages Overview

### Login (`/login`)
- Email & password form
- Link to register
- Redirect to dashboard on success

### Register (`/register`)
- Full registration form (name, email, phone, password, NIK, alamat)
- Form validation
- Link to login

### Dashboard (`/`)
- Statistics cards
- Vehicle list with filters
- Search functionality
- Add vehicle button

### Add Vehicle (`/add-vehicle`)
- Form tambah kendaraan
- Upload foto
- Select roda (2/4/6)
- Select produk BBM

### Vehicle Detail (`/vehicle/:id`)
- Full vehicle information
- Generate QR button (if approved)
- Display QR code
- Download QR code
- Edit/Delete options

### Profile (`/profile`)
- User information
- Edit profile form
- Upload foto profil
- Change password

## 🎨 Design System

### Colors
- Primary: `#0066cc` (blue)
- Success: `#10b981` (green)
- Danger: `#ef4444` (red)
- Warning: `#f59e0b` (orange)

### Typography
- Font: System default (SF Pro, Segoe UI, Roboto)
- Headings: Bold, larger sizes
- Body: Regular weight

### Spacing
- Base: 4px (1 unit in Tailwind)
- Small: 8px (2 units)
- Medium: 16px (4 units)
- Large: 24px (6 units)

## 🐛 Common Issues

### API Connection Failed
```bash
# Check backend is running
# Check VITE_API_URL in .env
# Check CORS settings in backend
```

### Token Expired
```bash
# Auto logout & redirect to login
# User needs to login again
```

### Upload Photo Failed
```bash
# Check file size (max 5MB)
# Check file type (jpg, jpeg, png)
```

## 📞 Support

Untuk issues atau questions, hubungi developer.

---

**Built with ❤️ using React + Vite**

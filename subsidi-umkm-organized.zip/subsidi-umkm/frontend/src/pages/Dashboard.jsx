import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import api from '../utils/api'
import toast from 'react-hot-toast'
import { FiPlus, FiSearch, FiFilter } from 'react-icons/fi'
import Layout from '../components/Layout'
import VehicleCard from '../components/VehicleCard'

export default function Dashboard() {
  const user = useAuthStore((state) => state.user)
  const [vehicles, setVehicles] = useState([])
  const [filteredVehicles, setFilteredVehicles] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    status: 'all',
    produk: 'all',
    search: '',
  })

  useEffect(() => {
    fetchVehicles()
  }, [])

  useEffect(() => {
    filterVehicles()
  }, [filters, vehicles])

  const fetchVehicles = async () => {
    try {
      const { data } = await api.get('/vehicles')
      if (data.success) {
        setVehicles(data.data)
        setFilteredVehicles(data.data)
      }
    } catch (error) {
      toast.error('Gagal memuat data kendaraan')
    } finally {
      setLoading(false)
    }
  }

  const filterVehicles = () => {
    let filtered = [...vehicles]

    // Filter by status
    if (filters.status !== 'all') {
      filtered = filtered.filter((v) => v.status === filters.status)
    }

    // Filter by produk BBM
    if (filters.produk !== 'all') {
      filtered = filtered.filter((v) => v.produk_bbm === filters.produk)
    }

    // Search by plat nomor
    if (filters.search) {
      filtered = filtered.filter((v) =>
        v.plat_nomor.toLowerCase().includes(filters.search.toLowerCase())
      )
    }

    setFilteredVehicles(filtered)
  }

  const handleDelete = async (id) => {
    if (!confirm('Yakin ingin menghapus kendaraan ini?')) return

    try {
      const { data } = await api.delete(`/vehicles/${id}`)
      if (data.success) {
        toast.success('Kendaraan berhasil dihapus')
        fetchVehicles()
      }
    } catch (error) {
      toast.error('Gagal menghapus kendaraan')
    }
  }

  return (
    <Layout>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Unit Subsidi</h1>
        <p className="text-gray-600">Kelola kendaraan Anda yang terdaftar untuk subsidi BBM</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="card p-4">
          <p className="text-sm text-gray-600 mb-1">Total Kendaraan</p>
          <p className="text-2xl font-bold text-gray-800">{vehicles.length}</p>
        </div>
        <div className="card p-4 bg-green-50 border-green-200">
          <p className="text-sm text-green-600 mb-1">Disetujui</p>
          <p className="text-2xl font-bold text-green-700">
            {vehicles.filter((v) => v.status === 'approved').length}
          </p>
        </div>
        <div className="card p-4 bg-yellow-50 border-yellow-200">
          <p className="text-sm text-yellow-600 mb-1">Pending</p>
          <p className="text-2xl font-bold text-yellow-700">
            {vehicles.filter((v) => v.status === 'pending').length}
          </p>
        </div>
        <div className="card p-4 bg-red-50 border-red-200">
          <p className="text-sm text-red-600 mb-1">Ditolak</p>
          <p className="text-2xl font-bold text-red-700">
            {vehicles.filter((v) => v.status === 'rejected').length}
          </p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="card p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="relative">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Cari plat nomor..."
              className="input pl-10"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            />
          </div>

          {/* Status Filter */}
          <select
            className="input"
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
          >
            <option value="all">Semua Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Disetujui</option>
            <option value="rejected">Ditolak</option>
          </select>

          {/* Produk Filter */}
          <select
            className="input"
            value={filters.produk}
            onChange={(e) => setFilters({ ...filters, produk: e.target.value })}
          >
            <option value="all">Semua Produk BBM</option>
            <option value="Pertalite">Pertalite</option>
            <option value="Solar">Solar</option>
            <option value="Pertamax">Pertamax</option>
          </select>

          {/* Add Button */}
          <Link to="/add-vehicle" className="btn btn-primary flex items-center justify-center gap-2">
            <FiPlus />
            <span>Tambah Unit</span>
          </Link>
        </div>
      </div>

      {/* Vehicle List */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredVehicles.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-gray-500 mb-4">
            {vehicles.length === 0
              ? 'Belum ada kendaraan terdaftar'
              : 'Tidak ada kendaraan yang sesuai filter'}
          </p>
          {vehicles.length === 0 && (
            <Link to="/add-vehicle" className="btn btn-primary inline-flex items-center gap-2">
              <FiPlus />
              <span>Tambah Kendaraan Pertama</span>
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((vehicle) => (
            <VehicleCard
              key={vehicle.id}
              vehicle={vehicle}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </Layout>
  )
}

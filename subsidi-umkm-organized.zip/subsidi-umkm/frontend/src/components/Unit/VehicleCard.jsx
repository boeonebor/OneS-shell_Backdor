import { Link } from 'react-router-dom'
import { FiEye, FiTrash2 } from 'react-icons/fi'

export default function VehicleCard({ vehicle, onDelete }) {
  const statusConfig = {
    pending: {
      label: 'Menunggu Verifikasi',
      className: 'badge-pending',
    },
    approved: {
      label: 'Verifikasi Berhasil',
      className: 'badge-approved',
    },
    rejected: {
      label: 'Verifikasi Ditolak',
      className: 'badge-rejected',
    },
  }

  const status = statusConfig[vehicle.status] || statusConfig.pending

  return (
    <div className="card p-6 hover:shadow-xl transition-shadow">
      {/* Foto Kendaraan */}
      <div className="relative mb-4 aspect-video bg-gray-200 rounded-lg overflow-hidden">
        {vehicle.foto_url ? (
          <img
            src={vehicle.foto_url}
            alt={vehicle.plat_nomor}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            <span>Tidak ada foto</span>
          </div>
        )}
        
        {/* Status Badge */}
        <div className="absolute top-2 right-2">
          <span className={`badge ${status.className}`}>{status.label}</span>
        </div>
      </div>

      {/* Info */}
      <div className="space-y-2">
        <h3 className="text-xl font-bold text-gray-800">{vehicle.plat_nomor}</h3>
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>Roda {vehicle.roda}</span>
          <span>{vehicle.produk_bbm}</span>
        </div>
        
        {vehicle.rejection_reason && (
          <p className="text-sm text-red-600 bg-red-50 p-2 rounded">
            Alasan ditolak: {vehicle.rejection_reason}
          </p>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-2 mt-4">
        <Link
          to={`/vehicle/${vehicle.id}`}
          className="btn btn-primary flex-1 flex items-center justify-center gap-2"
        >
          <FiEye />
          <span>Lihat Detail</span>
        </Link>
        <button
          onClick={() => onDelete(vehicle.id)}
          className="btn btn-danger flex items-center justify-center px-4"
        >
          <FiTrash2 />
        </button>
      </div>
    </div>
  )
}

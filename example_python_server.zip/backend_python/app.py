
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Enable CORS for all routes

# Dummy data
users = [
    {"id": 1, "username": "admin", "password": "password123", "role": "admin"},
    {"id": 2, "username": "user1", "password": "password123", "role": "user"}
]

vehicles = [
    {"id": 1, "name": "Motor A", "owner_id": 1},
    {"id": 2, "name": "Mobil B", "owner_id": 2}
]

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    user = next((u for u in users if u["username"] == username and u["password"] == password), None)

    if user:
        return jsonify({"message": "Login successful", "user": {"id": user["id"], "username": user["username"], "role": user["role"]}}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

@app.route("/api/vehicles", methods=["GET"])
def get_vehicles():
    return jsonify(vehicles), 200

@app.route("/api/vehicles", methods=["POST"])
def add_vehicle():
    data = request.get_json()
    new_vehicle = {"id": len(vehicles) + 1, "name": data.get("name"), "owner_id": data.get("owner_id")}
    vehicles.append(new_vehicle)
    return jsonify({"message": "Vehicle added", "vehicle": new_vehicle}), 201

if __name__ == "__main__":
    app.run(debug=True, port=5000)

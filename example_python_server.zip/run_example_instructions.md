# Cara Menjalankan Contoh Aplikasi Subsidi UMKM (Python)

Berikut adalah panduan untuk menjalankan contoh aplikasi **Subsidi UMKM** yang menggunakan backend Flask dan frontend statis yang disajikan oleh `http.server` Python.

## 1. Persiapan Lingkungan

Pastikan Anda memiliki Python 3 terinstal di sistem Anda. Kemudian, instal library yang diperlukan untuk backend Flask:

```bash
pip install Flask Flask-Cors
```

## 2. Menjalankan Backend (Flask)

1.  Navigasi ke direktori `subsidi-umkm/backend_python/`:
    ```bash
    cd /home/ubuntu/subsidi-umkm/backend_python/
    ```
2.  Jalankan aplikasi Flask:
    ```bash
    python app.py
    ```
    Backend akan berjalan di `http://127.0.0.1:5000`.

## 3. Menjalankan Frontend (Static HTTP Server)

1.  Buka terminal baru (jangan tutup terminal backend).
2.  Navigasi ke direktori `subsidi-umkm/frontend_static/`:
    ```bash
    cd /home/ubuntu/subsidi-umkm/frontend_static/
    ```
3.  Jalankan server HTTP sederhana Python:
    ```bash
    python -m http.server 8000
    ```
    Frontend akan berjalan di `http://127.0.0.1:8000`.

## 4. Mengakses Aplikasi

Setelah kedua server berjalan:

1.  Buka browser web Anda dan akses `http://127.0.0.1:8000`.
2.  Anda akan melihat halaman login. Gunakan kredensial berikut untuk login:
    *   **Username**: `admin` atau `user1`
    *   **Password**: `password123`
3.  Setelah login, Anda dapat mencoba mengambil daftar kendaraan atau menambahkan kendaraan baru.

**Catatan Penting:**
*   Pastikan kedua server berjalan secara bersamaan di terminal yang berbeda.
*   Backend Flask memiliki `CORS(app)` yang diaktifkan, sehingga frontend dapat berkomunikasi dengannya meskipun berjalan di port yang berbeda.
*   Ini adalah contoh sederhana dan tidak dimaksudkan untuk penggunaan produksi. Untuk produksi, Anda akan menggunakan setup web server yang lebih robust seperti Nginx/Apache dan deployment yang terpisah seperti yang dijelaskan sebelumnya.
